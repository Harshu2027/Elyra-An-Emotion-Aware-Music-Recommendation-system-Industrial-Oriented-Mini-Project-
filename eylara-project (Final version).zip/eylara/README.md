# EYLARA – Emotion-Based Music Recommender

> *"Feel the Music · Feed the Soul"*

EYLARA is a full-stack web application that detects your emotion via webcam and recommends music accordingly. Built with a dark neon futuristic **GROOVIVAL** aesthetic.

---

## ✨ Features

- 🎭 **Real-time emotion detection** via webcam + FastAPI backend
- 🎵 **Curated song recommendations** per emotion (7 moods × 6 songs)
- 🌈 **Neon glassmorphism UI** — dark base, glowing pink/cyan/purple
- ⚡ **Smooth animations** via Framer Motion
- 📊 **Dashboard** with scan history, stats & emotion distribution
- 🔐 **Auth pages** (Login & Register — wired for Firebase Auth)

---

## 📁 Project Structure

```
eylara/
├── frontend/               # Next.js 13 App Router (TypeScript)
│   ├── src/
│   │   ├── app/
│   │   │   ├── layout.tsx          # Root layout + navbar + ambient effects
│   │   │   ├── globals.css         # Neon/glassmorphism styles
│   │   │   ├── page.tsx            # Landing page
│   │   │   ├── login/page.tsx      # Login page
│   │   │   ├── register/page.tsx   # Register page
│   │   │   ├── dashboard/page.tsx  # User dashboard
│   │   │   ├── detect/page.tsx     # Webcam emotion detection
│   │   │   ├── music/page.tsx      # Music recommendations
│   │   │   └── not-found.tsx       # 404 page
│   │   ├── components/
│   │   │   ├── GlassCard.tsx       # Reusable glass card
│   │   │   ├── NeonButton.tsx      # Reusable neon button
│   │   │   └── EmotionBadge.tsx    # Emotion pill badge
│   │   └── lib/
│   │       ├── songs.ts            # Song data + emotion mapping
│   │       └── api.ts              # Backend API client
│   ├── tailwind.config.js
│   ├── next.config.js
│   └── package.json
│
└── backend/                # FastAPI (Python)
    ├── main.py             # API + emotion detection logic
    ├── requirements.txt
    └── .env.example
```

---

## 🚀 Getting Started

### Prerequisites

- **Node.js** >= 18
- **Python** >= 3.9
- A modern browser with webcam support

---

### 🐍 Backend Setup

```bash
# 1. Navigate to backend directory
cd eylara/backend

# 2. Create a Python virtual environment
python -m venv venv

# 3. Activate the virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# 4. Install dependencies
pip install -r requirements.txt

# 5. Copy environment file (optional)
cp .env.example .env

# 6. Start the development server
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The backend will be running at: **http://localhost:8000**

You can explore the auto-generated API docs at: **http://localhost:8000/docs**

---

### ⚛️ Frontend Setup

```bash
# 1. Navigate to frontend directory
cd eylara/frontend

# 2. Copy environment file
cp .env.local.example .env.local

# 3. Install dependencies
npm install

# 4. Start the development server
npm run dev
```

The frontend will be running at: **http://localhost:3000**

---

## 🌐 Pages Overview

| Route         | Page                    | Description                              |
|---------------|-------------------------|------------------------------------------|
| `/`           | Landing Page            | Hero section, features, CTA              |
| `/login`      | Login                   | Email/password auth form                 |
| `/register`   | Register                | Account creation form                    |
| `/dashboard`  | Dashboard               | Mood display, history, stats             |
| `/detect`     | Emotion Detection       | Webcam + detect emotion button           |
| `/music`      | Music Recommendations   | Songs filtered by detected emotion       |

---

## 🎵 Emotion → Music Mapping

| Emotion    | Vibe                     | Example Songs                          |
|------------|--------------------------|----------------------------------------|
| 😊 Happy    | Upbeat · Energetic        | Levitating, Blinding Lights, Happy     |
| 💧 Sad      | Calm · Introspective      | Someone Like You, Fix You, Skinny Love |
| ⚡ Angry    | Heavy · Intense           | HUMBLE., Killing in the Name, POWER    |
| ⭐ Surprised | Whimsical · Dynamic      | Bohemian Rhapsody, Mr. Brightside      |
| ◎ Neutral  | Chill · Ambient           | Midnight City, Electric Feel, Yellow   |
| 🌀 Fearful  | Cinematic · Tense         | Thriller, Radioactive, Disturbia       |
| 🔥 Disgusted | Punk · Rebellious        | Smells Like Teen Spirit, Holiday       |

---

## 🔌 API Reference

### `POST /detect-emotion`

Accepts a JSON body with an optional base64 frame. Returns detected emotion.

**Request:**
```json
{
  "frame": "<base64_image_string_or_null>",
  "simulate": true
}
```

**Response:**
```json
{
  "emotion": "happy",
  "confidence": 0.7832,
  "timestamp": 1711900000.123,
  "all_scores": {
    "happy": 0.7832,
    "neutral": 0.1021,
    "sad": 0.0512,
    "angry": 0.0321,
    "surprised": 0.0198,
    "fearful": 0.0082,
    "disgusted": 0.0034
  }
}
```

### `GET /health`
Returns `{ "status": "ok" }` — used by frontend to check if backend is alive.

### `GET /emotions`
Returns list of all supported emotions.

---

## 🔧 Replacing the Dummy Emotion Model

The backend currently uses a **weighted random** emotion picker. To plug in a real model:

1. Install your model library (e.g., `deepface`, `fer`, `transformers`)
2. Edit `detect_emotion_dummy()` in `backend/main.py`
3. Replace the random logic with actual inference:

```python
# Example with FER (pip install fer)
from fer import FER
import cv2, numpy as np, base64

def detect_emotion_real(frame_b64: str) -> dict:
    img_data = base64.b64decode(frame_b64)
    np_arr = np.frombuffer(img_data, np.uint8)
    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    
    detector = FER(mtcnn=True)
    result = detector.detect_emotions(frame)
    if not result:
        return detect_emotion_dummy()  # fallback
    
    emotions = result[0]["emotions"]
    top = max(emotions, key=emotions.get)
    return {
        "emotion": top,
        "confidence": emotions[top],
        "all_scores": emotions,
    }
```

---

## 🔐 Firebase Auth Integration

The login/register pages are structured for Firebase Auth. To wire it up:

1. Create a Firebase project at https://console.firebase.google.com
2. Enable **Email/Password** authentication
3. Add your config keys to `frontend/.env.local`
4. Install the SDK: `npm install firebase`
5. Create `frontend/src/lib/firebase.ts` with your `initializeApp` config
6. Replace the `setTimeout` simulations in `/login/page.tsx` and `/register/page.tsx` with `signInWithEmailAndPassword` / `createUserWithEmailAndPassword`

---

## 🎨 Design System

| Token         | Value       | Usage                  |
|---------------|-------------|------------------------|
| `#0f0f1a`     | Dark base   | Page background        |
| `#151528`     | Dark card   | Glass card base        |
| `#ff2d78`     | Neon pink   | Primary actions, happy |
| `#00f5ff`     | Neon cyan   | Secondary, sad, links  |
| `#bf00ff`     | Neon purple | Accents, surprised     |
| `#39ff14`     | Neon green  | Neutral, status ok     |
| `#ff6b00`     | Neon orange | Angry emotion          |
| Orbitron      | Display font| Headings, labels       |
| Rajdhani      | Body font   | Body text              |
| Share Tech Mono | Mono font | Tags, metadata, code   |

---

## 📦 Tech Stack

| Layer     | Technology              |
|-----------|-------------------------|
| Frontend  | Next.js 13, TypeScript  |
| Styling   | Tailwind CSS            |
| Animation | Framer Motion           |
| Webcam    | react-webcam            |
| Backend   | FastAPI (Python)        |
| HTTP      | Uvicorn ASGI server     |
| Auth      | Firebase Auth (optional)|

---

## 🛠 Build for Production

### Frontend
```bash
cd frontend
npm run build
npm start
```

### Backend
```bash
cd backend
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

---

## 📝 License

MIT — build freely, vibe loudly.

---

*Built with ♥ and neon by EYLARA*
