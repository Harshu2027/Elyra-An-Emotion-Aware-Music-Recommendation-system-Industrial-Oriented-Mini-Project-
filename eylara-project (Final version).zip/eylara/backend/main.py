import random
import base64
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional
import time

app = FastAPI(title="EYLARA Emotion API", version="1.0.0")

# Allow frontend to call backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

EMOTIONS = ["happy", "sad", "angry", "surprised", "neutral", "fearful", "disgusted"]

EMOTION_WEIGHTS = {
    "happy": 0.30,
    "neutral": 0.25,
    "sad": 0.20,
    "angry": 0.10,
    "surprised": 0.08,
    "fearful": 0.04,
    "disgusted": 0.03,
}

class FrameRequest(BaseModel):
    frame: Optional[str] = None  # base64 encoded image (optional for dummy mode)
    simulate: Optional[bool] = True

class EmotionResponse(BaseModel):
    emotion: str
    confidence: float
    timestamp: float
    all_scores: dict

def detect_emotion_dummy(frame_data: Optional[str] = None) -> dict:
    """
    Dummy emotion detection function.
    In production, replace with a real model like DeepFace or FER.
    """
    # Simulate slight processing delay
    time.sleep(0.3)

    emotions = list(EMOTION_WEIGHTS.keys())
    weights = list(EMOTION_WEIGHTS.values())

    detected = random.choices(emotions, weights=weights, k=1)[0]

    # Generate plausible confidence scores summing to 1
    scores = {}
    remaining = 1.0
    shuffled = emotions[:]
    random.shuffle(shuffled)

    for i, emotion in enumerate(shuffled):
        if i == len(shuffled) - 1:
            scores[emotion] = round(max(0.01, remaining), 4)
        else:
            val = round(random.uniform(0.01, remaining * 0.6), 4)
            scores[emotion] = val
            remaining -= val

    # Boost the detected emotion
    scores[detected] = round(min(0.95, max(scores[detected], random.uniform(0.45, 0.85))), 4)
    # Re-normalize
    total = sum(scores.values())
    scores = {k: round(v / total, 4) for k, v in scores.items()}

    return {
        "emotion": detected,
        "confidence": scores[detected],
        "all_scores": scores,
    }

@app.get("/")
def root():
    return {"message": "EYLARA Emotion API is running 🎵", "version": "1.0.0"}

@app.get("/health")
def health():
    return {"status": "ok", "timestamp": time.time()}

@app.post("/detect-emotion", response_model=EmotionResponse)
def detect_emotion(request: FrameRequest):
    """
    Detect emotion from a webcam frame.
    Currently uses dummy logic — replace frame processing with real model.
    """
    try:
        result = detect_emotion_dummy(request.frame)
        return EmotionResponse(
            emotion=result["emotion"],
            confidence=result["confidence"],
            timestamp=time.time(),
            all_scores=result["all_scores"],
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Emotion detection failed: {str(e)}")

@app.get("/emotions")
def list_emotions():
    """Return all possible emotions."""
    return {"emotions": EMOTIONS}
