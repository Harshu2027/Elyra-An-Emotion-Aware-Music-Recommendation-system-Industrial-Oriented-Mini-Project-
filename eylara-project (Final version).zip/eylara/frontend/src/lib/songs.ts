export type Emotion = 'happy' | 'sad' | 'angry' | 'surprised' | 'neutral' | 'fearful' | 'disgusted'

export interface Song {
  id: string
  title: string
  artist: string
  genre: string
  bpm: number
  duration: string
  mood: string
  color: string
}

export const EMOTION_CONFIG: Record<Emotion, {
  label: string
  emoji: string
  color: string
  gradient: string
  description: string
  vibe: string
}> = {
  happy: {
    label: 'HAPPY',
    emoji: '✨',
    color: '#ff2d78',
    gradient: 'linear-gradient(135deg, #ff2d78, #ff6b35)',
    description: 'Pure joy radiating from your soul',
    vibe: 'Upbeat · Energetic · Feel-Good',
  },
  sad: {
    label: 'SAD',
    emoji: '💧',
    color: '#00f5ff',
    gradient: 'linear-gradient(135deg, #00f5ff, #0088cc)',
    description: 'Embracing the beautiful melancholy',
    vibe: 'Calm · Introspective · Soulful',
  },
  angry: {
    label: 'ANGRY',
    emoji: '⚡',
    color: '#ff6b00',
    gradient: 'linear-gradient(135deg, #ff6b00, #ff2d00)',
    description: 'Raw power surging through you',
    vibe: 'Intense · Heavy · Relentless',
  },
  surprised: {
    label: 'SURPRISED',
    emoji: '⭐',
    color: '#bf00ff',
    gradient: 'linear-gradient(135deg, #bf00ff, #6600cc)',
    description: 'Wonder and amazement unlocked',
    vibe: 'Whimsical · Dynamic · Unexpected',
  },
  neutral: {
    label: 'NEUTRAL',
    emoji: '◎',
    color: '#39ff14',
    gradient: 'linear-gradient(135deg, #39ff14, #00cc55)',
    description: 'Balanced and centered state of mind',
    vibe: 'Chill · Steady · Ambient',
  },
  fearful: {
    label: 'FEARFUL',
    emoji: '🌀',
    color: '#9966ff',
    gradient: 'linear-gradient(135deg, #9966ff, #6633cc)',
    description: 'Tension and anticipation in the air',
    vibe: 'Cinematic · Tense · Atmospheric',
  },
  disgusted: {
    label: 'DISGUSTED',
    emoji: '🔥',
    color: '#ff4444',
    gradient: 'linear-gradient(135deg, #ff4444, #cc0000)',
    description: 'Defiant and rebellious energy',
    vibe: 'Punk · Raw · Unapologetic',
  },
}

export const SONG_DATABASE: Record<Emotion, Song[]> = {
  happy: [
    { id: 'h1', title: 'Levitating', artist: 'Dua Lipa', genre: 'Pop', bpm: 103, duration: '3:23', mood: 'Euphoric', color: '#ff2d78' },
    { id: 'h2', title: 'Happy', artist: 'Pharrell Williams', genre: 'Pop/Funk', bpm: 160, duration: '3:53', mood: 'Joyful', color: '#ff6b35' },
    { id: 'h3', title: 'Shake It Off', artist: 'Taylor Swift', genre: 'Pop', bpm: 160, duration: '3:39', mood: 'Carefree', color: '#ff2d78' },
    { id: 'h4', title: 'Can\'t Stop the Feeling', artist: 'Justin Timberlake', genre: 'Funk Pop', bpm: 113, duration: '3:56', mood: 'Groovy', color: '#ffaa00' },
    { id: 'h5', title: 'Blinding Lights', artist: 'The Weeknd', genre: 'Synth-Pop', bpm: 171, duration: '3:20', mood: 'Electric', color: '#ff2d78' },
    { id: 'h6', title: 'Uptown Funk', artist: 'Mark Ronson ft. Bruno Mars', genre: 'Funk/Soul', bpm: 115, duration: '4:30', mood: 'Funky', color: '#ffcc00' },
  ],
  sad: [
    { id: 's1', title: 'Someone Like You', artist: 'Adele', genre: 'Soul', bpm: 67, duration: '4:45', mood: 'Longing', color: '#00f5ff' },
    { id: 's2', title: 'The Night We Met', artist: 'Lord Huron', genre: 'Indie Folk', bpm: 89, duration: '3:28', mood: 'Nostalgic', color: '#00aacc' },
    { id: 's3', title: 'Let Her Go', artist: 'Passenger', genre: 'Folk', bpm: 76, duration: '4:14', mood: 'Reflective', color: '#00ccff' },
    { id: 's4', title: 'Fix You', artist: 'Coldplay', genre: 'Alternative Rock', bpm: 69, duration: '4:55', mood: 'Hopeful', color: '#0099ee' },
    { id: 's5', title: 'Skinny Love', artist: 'Bon Iver', genre: 'Indie Folk', bpm: 96, duration: '3:58', mood: 'Raw', color: '#0077bb' },
    { id: 's6', title: 'Motion Picture Soundtrack', artist: 'Radiohead', genre: 'Art Rock', bpm: 55, duration: '7:04', mood: 'Ethereal', color: '#00f5ff' },
  ],
  angry: [
    { id: 'a1', title: 'HUMBLE.', artist: 'Kendrick Lamar', genre: 'Hip-Hop', bpm: 150, duration: '2:57', mood: 'Intense', color: '#ff6b00' },
    { id: 'a2', title: 'Killing in the Name', artist: 'Rage Against the Machine', genre: 'Metal/Rap', bpm: 90, duration: '5:13', mood: 'Rage', color: '#ff2200' },
    { id: 'a3', title: 'Body Count', artist: 'Ice-T', genre: 'Rap Metal', bpm: 120, duration: '4:36', mood: 'Defiant', color: '#ff4400' },
    { id: 'a4', title: 'POWER', artist: 'Kanye West', genre: 'Hip-Hop', bpm: 89, duration: '4:52', mood: 'Dominant', color: '#ff6600' },
    { id: 'a5', title: 'Guerrilla Radio', artist: 'Rage Against the Machine', genre: 'Rock', bpm: 100, duration: '3:25', mood: 'Electric', color: '#ff3300' },
    { id: 'a6', title: 'Bulls on Parade', artist: 'RATM', genre: 'Funk Metal', bpm: 105, duration: '3:51', mood: 'Ferocious', color: '#ff5500' },
  ],
  surprised: [
    { id: 'su1', title: 'Bohemian Rhapsody', artist: 'Queen', genre: 'Rock', bpm: 72, duration: '5:55', mood: 'Epic', color: '#bf00ff' },
    { id: 'su2', title: 'Stairway to Heaven', artist: 'Led Zeppelin', genre: 'Rock', bpm: 82, duration: '8:02', mood: 'Transcendent', color: '#9900cc' },
    { id: 'su3', title: 'Supermassive Black Hole', artist: 'Muse', genre: 'Alt Rock', bpm: 138, duration: '3:32', mood: 'Cosmic', color: '#cc00ff' },
    { id: 'su4', title: 'Madness', artist: 'Muse', genre: 'Art Rock', bpm: 145, duration: '4:41', mood: 'Wild', color: '#aa00ff' },
    { id: 'su5', title: 'Mr. Brightside', artist: 'The Killers', genre: 'Indie Rock', bpm: 148, duration: '3:42', mood: 'Euphoric', color: '#bf00ff' },
    { id: 'su6', title: 'Take On Me', artist: 'a-ha', genre: 'Synth-Pop', bpm: 168, duration: '3:46', mood: 'Iconic', color: '#dd00ff' },
  ],
  neutral: [
    { id: 'n1', title: 'Midnight City', artist: 'M83', genre: 'Synth-Pop', bpm: 105, duration: '4:03', mood: 'Dreamy', color: '#39ff14' },
    { id: 'n2', title: 'Breathe (2 AM)', artist: 'Anna Nalick', genre: 'Folk Pop', bpm: 84, duration: '4:06', mood: 'Calm', color: '#00cc55' },
    { id: 'n3', title: 'Lost in Japan', artist: 'Shawn Mendes', genre: 'Pop', bpm: 108, duration: '3:09', mood: 'Smooth', color: '#44ff44' },
    { id: 'n4', title: 'Electric Feel', artist: 'MGMT', genre: 'Indie Pop', bpm: 104, duration: '3:49', mood: 'Groovy', color: '#39ff14' },
    { id: 'n5', title: 'Yellow', artist: 'Coldplay', genre: 'Brit Pop', bpm: 87, duration: '4:29', mood: 'Warm', color: '#66ff33' },
    { id: 'n6', title: 'Float On', artist: 'Modest Mouse', genre: 'Indie Rock', bpm: 105, duration: '3:29', mood: 'Easy', color: '#33ee11' },
  ],
  fearful: [
    { id: 'f1', title: 'Welcome to the Black Parade', artist: 'My Chemical Romance', genre: 'Emo Rock', bpm: 93, duration: '5:11', mood: 'Dramatic', color: '#9966ff' },
    { id: 'f2', title: 'Immigrant Song', artist: 'Led Zeppelin', genre: 'Hard Rock', bpm: 113, duration: '2:27', mood: 'Powerful', color: '#7744cc' },
    { id: 'f3', title: 'Thriller', artist: 'Michael Jackson', genre: 'Pop/Funk', bpm: 118, duration: '5:57', mood: 'Suspenseful', color: '#8833ff' },
    { id: 'f4', title: 'Disturbia', artist: 'Rihanna', genre: 'Electropop', bpm: 126, duration: '3:56', mood: 'Eerie', color: '#9955ff' },
    { id: 'f5', title: 'Radioactive', artist: 'Imagine Dragons', genre: 'Alternative', bpm: 136, duration: '3:06', mood: 'Apocalyptic', color: '#6622bb' },
    { id: 'f6', title: 'Land of Confusion', artist: 'Disturbed', genre: 'Heavy Metal', bpm: 115, duration: '4:48', mood: 'Haunting', color: '#aa77ff' },
  ],
  disgusted: [
    { id: 'd1', title: 'Smells Like Teen Spirit', artist: 'Nirvana', genre: 'Grunge', bpm: 117, duration: '5:01', mood: 'Rebellious', color: '#ff4444' },
    { id: 'd2', title: 'Holiday', artist: 'Green Day', genre: 'Punk Rock', bpm: 147, duration: '3:52', mood: 'Protest', color: '#ff2222' },
    { id: 'd3', title: 'Anarchy in the UK', artist: 'Sex Pistols', genre: 'Punk', bpm: 200, duration: '3:32', mood: 'Defiant', color: '#ff5555' },
    { id: 'd4', title: 'Cochise', artist: 'Audioslave', genre: 'Hard Rock', bpm: 120, duration: '3:44', mood: 'Blazing', color: '#ff3333' },
    { id: 'd5', title: 'Killing Me Softly', artist: 'Fugees', genre: 'Hip-Hop', bpm: 90, duration: '4:57', mood: 'Intense', color: '#ff6666' },
    { id: 'd6', title: 'Enter Sandman', artist: 'Metallica', genre: 'Heavy Metal', bpm: 123, duration: '5:32', mood: 'Dark', color: '#cc0000' },
  ],
}

export function getEmotionConfig(emotion: string) {
  return EMOTION_CONFIG[emotion as Emotion] ?? EMOTION_CONFIG.neutral
}

export function getSongs(emotion: string): Song[] {
  return SONG_DATABASE[emotion as Emotion] ?? SONG_DATABASE.neutral
}
