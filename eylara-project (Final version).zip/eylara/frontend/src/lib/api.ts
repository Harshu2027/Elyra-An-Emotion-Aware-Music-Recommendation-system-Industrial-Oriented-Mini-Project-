const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'

export interface EmotionResult {
  emotion: string
  confidence: number
  timestamp: number
  all_scores: Record<string, number>
}

export async function detectEmotion(frameBase64?: string): Promise<EmotionResult> {
  const response = await fetch(`${API_BASE}/detect-emotion`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      frame: frameBase64 ?? null,
      simulate: true,
    }),
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({}))
    throw new Error(err.detail || `API error: ${response.status}`)
  }

  return response.json()
}

export async function healthCheck(): Promise<boolean> {
  try {
    const response = await fetch(`${API_BASE}/health`, { signal: AbortSignal.timeout(3000) })
    return response.ok
  } catch {
    return false
  }
}
