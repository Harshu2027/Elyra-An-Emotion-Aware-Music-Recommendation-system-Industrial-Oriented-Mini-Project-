'use client'
import { motion, HTMLMotionProps } from 'framer-motion'
import { ReactNode } from 'react'
import clsx from 'clsx'

type ColorVariant = 'pink' | 'cyan' | 'purple' | 'green' | 'default'

interface GlassCardProps extends Omit<HTMLMotionProps<'div'>, 'children'> {
  children: ReactNode
  variant?: ColorVariant
  hover?: boolean
  padding?: 'sm' | 'md' | 'lg'
  className?: string
}

const COLORS: Record<ColorVariant, string> = {
  pink: 'rgba(255,45,120,0.25)',
  cyan: 'rgba(0,245,255,0.25)',
  purple: 'rgba(191,0,255,0.25)',
  green: 'rgba(57,255,20,0.25)',
  default: 'rgba(191,0,255,0.2)',
}

const PADDING = {
  sm: 'p-4',
  md: 'p-6',
  lg: 'p-8',
}

export default function GlassCard({
  children,
  variant = 'default',
  hover = false,
  padding = 'md',
  className,
  ...props
}: GlassCardProps) {
  return (
    <motion.div
      whileHover={hover ? { y: -6, scale: 1.01 } : undefined}
      transition={{ duration: 0.3 }}
      className={clsx(
        'rounded-2xl',
        'backdrop-blur-xl',
        PADDING[padding],
        className
      )}
      style={{
        background: 'rgba(21, 21, 40, 0.6)',
        border: `1px solid ${COLORS[variant]}`,
        boxShadow: '0 8px 32px rgba(0,0,0,0.3)',
        ...props.style,
      }}
      {...props}
    >
      {children}
    </motion.div>
  )
}
