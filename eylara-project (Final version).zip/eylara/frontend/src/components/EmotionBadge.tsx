'use client'
import { motion } from 'framer-motion'
import { getEmotionConfig } from '@/lib/songs'

interface EmotionBadgeProps {
  emotion: string
  size?: 'sm' | 'md' | 'lg'
  animated?: boolean
}

const SIZES = {
  sm: { text: 'text-xs', pad: 'px-3 py-1', emoji: 'text-sm', gap: 'gap-1.5' },
  md: { text: 'text-sm', pad: 'px-4 py-2', emoji: 'text-base', gap: 'gap-2' },
  lg: { text: 'text-base', pad: 'px-5 py-2.5', emoji: 'text-xl', gap: 'gap-2.5' },
}

export default function EmotionBadge({ emotion, size = 'md', animated = true }: EmotionBadgeProps) {
  const config = getEmotionConfig(emotion)
  const sz = SIZES[size]

  return (
    <motion.div
      initial={animated ? { opacity: 0, scale: 0.8 } : undefined}
      animate={animated ? { opacity: 1, scale: 1 } : undefined}
      className={`inline-flex items-center ${sz.gap} ${sz.pad} rounded-full font-display font-bold tracking-widest uppercase`}
      style={{
        color: config.color,
        background: `${config.color}15`,
        border: `1px solid ${config.color}50`,
        boxShadow: `0 0 15px ${config.color}25`,
        letterSpacing: '0.15em',
      }}
    >
      <span className={sz.emoji}>{config.emoji}</span>
      <span className={sz.text}>{config.label}</span>
    </motion.div>
  )
}
