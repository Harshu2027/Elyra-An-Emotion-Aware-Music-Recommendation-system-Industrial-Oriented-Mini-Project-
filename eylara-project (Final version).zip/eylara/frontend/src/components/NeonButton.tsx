'use client'
import { motion, HTMLMotionProps } from 'framer-motion'
import { ReactNode } from 'react'
import clsx from 'clsx'

type ButtonVariant = 'pink' | 'cyan' | 'outline-cyan' | 'outline-pink' | 'outline-purple'

interface NeonButtonProps extends Omit<HTMLMotionProps<'button'>, 'children'> {
  children: ReactNode
  variant?: ButtonVariant
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
  className?: string
}

const VARIANT_STYLES: Record<ButtonVariant, React.CSSProperties> = {
  pink: {
    background: 'linear-gradient(135deg, #ff2d78, #bf00ff)',
    color: 'white',
    border: 'none',
    boxShadow: '0 0 20px rgba(255,45,120,0.4), 0 0 40px rgba(191,0,255,0.2)',
  },
  cyan: {
    background: 'linear-gradient(135deg, #00f5ff, #bf00ff)',
    color: '#0f0f1a',
    border: 'none',
    boxShadow: '0 0 20px rgba(0,245,255,0.4), 0 0 40px rgba(191,0,255,0.2)',
  },
  'outline-cyan': {
    background: 'transparent',
    color: '#00f5ff',
    border: '1px solid rgba(0,245,255,0.6)',
  },
  'outline-pink': {
    background: 'transparent',
    color: '#ff2d78',
    border: '1px solid rgba(255,45,120,0.6)',
  },
  'outline-purple': {
    background: 'transparent',
    color: '#bf00ff',
    border: '1px solid rgba(191,0,255,0.6)',
  },
}

const SIZES = {
  sm: 'px-4 py-2 text-xs',
  md: 'px-6 py-3 text-sm',
  lg: 'px-10 py-4 text-sm',
}

export default function NeonButton({
  children,
  variant = 'pink',
  size = 'md',
  loading = false,
  className,
  disabled,
  ...props
}: NeonButtonProps) {
  return (
    <motion.button
      whileHover={disabled || loading ? {} : { scale: 1.04, y: -1 }}
      whileTap={disabled || loading ? {} : { scale: 0.97 }}
      transition={{ duration: 0.2 }}
      disabled={disabled || loading}
      className={clsx(
        'rounded-xl font-display font-bold tracking-widest uppercase',
        'transition-all duration-300 cursor-pointer',
        'disabled:opacity-50 disabled:cursor-not-allowed',
        SIZES[size],
        className
      )}
      style={{
        ...VARIANT_STYLES[variant],
        letterSpacing: '0.15em',
        ...(props.style ?? {}),
      }}
      {...props}
    >
      {loading ? (
        <span className="flex items-center justify-center gap-2">
          <motion.span
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
            className="inline-block w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full"
          />
          LOADING...
        </span>
      ) : (
        children
      )}
    </motion.button>
  )
}
