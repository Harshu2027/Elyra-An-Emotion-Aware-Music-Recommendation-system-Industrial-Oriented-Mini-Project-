'use client'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function RegisterPage() {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!form.name || !form.email || !form.password) {
      setError('All fields are required')
      return
    }
    if (form.password !== form.confirm) {
      setError('Passwords do not match')
      return
    }
    if (form.password.length < 6) {
      setError('Password must be at least 6 characters')
      return
    }
    setLoading(true)
    // Simulate registration — replace with Firebase Auth
    await new Promise((r) => setTimeout(r, 1500))
    setLoading(false)
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-24">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-10">
          <Link href="/">
            <h1
              className="font-display font-black text-4xl neon-text-pink cursor-pointer"
              style={{ letterSpacing: '0.25em' }}
            >
              EYLARA
            </h1>
          </Link>
          <p className="font-mono text-xs text-slate-500 mt-2 tracking-widest">
            CREATE YOUR ACCOUNT
          </p>
        </div>

        <div
          className="glass-card p-8"
          style={{ borderColor: 'rgba(255, 45, 120, 0.2)' }}
        >
          {error && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6 px-4 py-3 rounded-lg text-sm font-body"
              style={{
                background: 'rgba(255, 45, 120, 0.1)',
                border: '1px solid rgba(255, 45, 120, 0.3)',
                color: '#ff2d78',
              }}
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {[
              { name: 'name', label: 'DISPLAY NAME', type: 'text', placeholder: 'Your name' },
              { name: 'email', label: 'EMAIL', type: 'email', placeholder: 'your@email.com' },
              { name: 'password', label: 'PASSWORD', type: 'password', placeholder: '••••••••' },
              { name: 'confirm', label: 'CONFIRM PASSWORD', type: 'password', placeholder: '••••••••' },
            ].map((field, i) => (
              <motion.div
                key={field.name}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 * i + 0.3 }}
              >
                <label className="font-mono text-xs text-slate-400 tracking-widest block mb-2">
                  {field.label}
                </label>
                <input
                  name={field.name}
                  type={field.type}
                  value={form[field.name as keyof typeof form]}
                  onChange={handleChange}
                  placeholder={field.placeholder}
                  className="neon-input w-full px-4 py-3 rounded-lg"
                />
              </motion.div>
            ))}

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="btn-neon-pink w-full py-4 rounded-lg text-sm mt-2"
              style={{ letterSpacing: '0.2em' }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <motion.span
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full"
                  />
                  CREATING ACCOUNT...
                </span>
              ) : (
                '✦ CREATE ACCOUNT'
              )}
            </motion.button>
          </form>

          <div className="mt-8 pt-6 border-t border-dark-border text-center">
            <p className="font-body text-slate-400 text-sm">
              Already have an account?{' '}
              <Link href="/login">
                <span className="text-neon-cyan hover:opacity-80 cursor-pointer font-semibold">
                  SIGN IN
                </span>
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
