'use client'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useState, useEffect } from 'react'
import { EMOTION_CONFIG, type Emotion } from '@/lib/songs'

const HISTORY = [
  { emotion: 'happy', time: '2 min ago', songs: 6 },
  { emotion: 'neutral', time: '1 hour ago', songs: 6 },
  { emotion: 'sad', time: '3 hours ago', songs: 6 },
  { emotion: 'angry', time: 'Yesterday', songs: 6 },
  { emotion: 'surprised', time: '2 days ago', songs: 6 },
]

const STATS = [
  { label: 'SCANS TODAY', value: '7', icon: '◎', color: '#00f5ff' },
  { label: 'SONGS PLAYED', value: '42', icon: '♫', color: '#ff2d78' },
  { label: 'EMOTIONS', value: '5', icon: '◈', color: '#bf00ff' },
  { label: 'STREAK', value: '12 DAYS', icon: '⚡', color: '#39ff14' },
]

function StatCard({ stat, index }: { stat: typeof STATS[0]; index: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 + 0.3, duration: 0.6 }}
      whileHover={{ y: -6, scale: 1.02 }}
      className="glass-card p-6 text-center"
      style={{ borderColor: `${stat.color}30` }}
    >
      <div
        className="text-3xl mb-2"
        style={{ color: stat.color, filter: `drop-shadow(0 0 10px ${stat.color})` }}
      >
        {stat.icon}
      </div>
      <div
        className="font-display font-black text-2xl mb-1"
        style={{ color: stat.color }}
      >
        {stat.value}
      </div>
      <div className="font-mono text-xs text-slate-500 tracking-widest">{stat.label}</div>
    </motion.div>
  )
}

function EmotionBar({ emotion, count, max, color }: {
  emotion: string; count: number; max: number; color: string
}) {
  return (
    <div className="flex items-center gap-3">
      <span className="font-mono text-xs text-slate-400 w-20 tracking-wider uppercase">{emotion}</span>
      <div className="flex-1 progress-bar-neon">
        <motion.div
          className="progress-bar-fill"
          initial={{ width: 0 }}
          animate={{ width: `${(count / max) * 100}%` }}
          transition={{ duration: 1, delay: 0.5, ease: 'easeOut' }}
          style={{ background: color }}
        />
      </div>
      <span className="font-mono text-xs text-slate-500 w-6 text-right">{count}</span>
    </div>
  )
}

export default function DashboardPage() {
  const [currentMood, setCurrentMood] = useState<Emotion>('neutral')

  useEffect(() => {
    // Load last detected emotion from sessionStorage
    const saved = sessionStorage.getItem('eylara_emotion') as Emotion | null
    if (saved) setCurrentMood(saved)
  }, [])

  const moodConfig = EMOTION_CONFIG[currentMood]
  const emotionStats = [
    { emotion: 'happy', count: 12, color: '#ff2d78' },
    { emotion: 'neutral', count: 8, color: '#39ff14' },
    { emotion: 'sad', count: 5, color: '#00f5ff' },
    { emotion: 'angry', count: 3, color: '#ff6b00' },
    { emotion: 'surprised', count: 2, color: '#bf00ff' },
  ]

  return (
    <div className="min-h-screen px-6 py-28 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="mb-12"
      >
        <p className="font-mono text-xs text-slate-500 tracking-widest mb-2">WELCOME BACK</p>
        <h1
          className="font-display font-black text-4xl md:text-5xl"
          style={{ letterSpacing: '0.1em' }}
        >
          <span className="neon-text-cyan">YOUR</span>{' '}
          <span className="neon-text-purple">DASHBOARD</span>
        </h1>
      </motion.div>

      {/* Current Mood Hero Card */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="glass-card p-8 mb-10 relative overflow-hidden"
        style={{ borderColor: `${moodConfig.color}40` }}
      >
        {/* Background glow */}
        <div
          className="absolute inset-0 opacity-5"
          style={{ background: moodConfig.gradient }}
        />

        <div className="relative flex flex-col md:flex-row items-start md:items-center gap-6 justify-between">
          <div>
            <p className="font-mono text-xs text-slate-500 tracking-widest mb-2">CURRENT MOOD</p>
            <div className="flex items-center gap-3 mb-3">
              <span className="text-4xl">{moodConfig.emoji}</span>
              <h2
                className="font-display font-black text-4xl"
                style={{ color: moodConfig.color, letterSpacing: '0.15em' }}
              >
                {moodConfig.label}
              </h2>
            </div>
            <p className="font-body text-slate-300 text-lg mb-2">{moodConfig.description}</p>
            <p
              className="font-mono text-xs tracking-widest"
              style={{ color: `${moodConfig.color}99` }}
            >
              {moodConfig.vibe}
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <Link href="/detect">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                className="btn-neon-pink px-8 py-3 rounded-xl text-sm"
                style={{ letterSpacing: '0.15em' }}
              >
                ◎ RESCAN
              </motion.button>
            </Link>
            <Link href="/music">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.97 }}
                className="btn-outline-neon px-8 py-3 rounded-xl text-sm"
                style={{ letterSpacing: '0.15em' }}
              >
                ♫ MY SONGS
              </motion.button>
            </Link>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5 mb-10">
        {STATS.map((stat, i) => (
          <StatCard key={stat.label} stat={stat} index={i} />
        ))}
      </div>

      {/* Bottom grid */}
      <div className="grid md:grid-cols-2 gap-8">
        {/* Scan History */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6, duration: 0.7 }}
          className="glass-card-cyan p-6"
        >
          <h3
            className="font-display font-bold text-sm tracking-widest mb-6 neon-text-cyan"
            style={{ letterSpacing: '0.2em' }}
          >
            ◎ SCAN HISTORY
          </h3>
          <div className="space-y-4">
            {HISTORY.map((item, i) => {
              const cfg = EMOTION_CONFIG[item.emotion as Emotion]
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.7 + i * 0.08 }}
                  className="flex items-center justify-between py-3 border-b border-dark-border last:border-0"
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="w-8 h-8 rounded-full flex items-center justify-center text-sm"
                      style={{
                        background: `${cfg.color}18`,
                        border: `1px solid ${cfg.color}40`,
                        color: cfg.color,
                      }}
                    >
                      {cfg.emoji}
                    </span>
                    <div>
                      <p
                        className="font-mono text-xs font-bold tracking-wider"
                        style={{ color: cfg.color }}
                      >
                        {cfg.label}
                      </p>
                      <p className="font-body text-xs text-slate-500">{item.time}</p>
                    </div>
                  </div>
                  <span className="font-mono text-xs text-slate-500">
                    {item.songs} songs
                  </span>
                </motion.div>
              )
            })}
          </div>
        </motion.div>

        {/* Emotion Distribution */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7, duration: 0.7 }}
          className="glass-card-pink p-6"
        >
          <h3
            className="font-display font-bold text-sm tracking-widest mb-6 neon-text-pink"
            style={{ letterSpacing: '0.2em' }}
          >
            ◈ EMOTION STATS
          </h3>
          <div className="space-y-4">
            {emotionStats.map((item, i) => (
              <motion.div
                key={item.emotion}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 + i * 0.1 }}
              >
                <EmotionBar {...item} max={12} />
              </motion.div>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-dark-border">
            <p className="font-mono text-xs text-slate-500 tracking-wider text-center">
              TOTAL SCANS: <span className="text-neon-cyan">30</span>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
