'use client'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { useState } from 'react'
import { useRouter } from 'next/navigation'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!email || !password) {
      setError('Please fill all fields')
      return
    }
    setLoading(true)
    // Simulate auth — replace with Firebase Auth
    await new Promise((r) => setTimeout(r, 1200))
    setLoading(false)
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-6 pt-24">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-10">
          <Link href="/">
            <h1
              className="font-display font-black text-4xl neon-text-cyan cursor-pointer"
              style={{ letterSpacing: '0.25em' }}
            >
              EYLARA
            </h1>
          </Link>
          <p className="font-mono text-xs text-slate-500 mt-2 tracking-widest">
            SIGN IN TO YOUR ACCOUNT
          </p>
        </div>

        <div
          className="glass-card p-8"
          style={{ borderColor: 'rgba(0, 245, 255, 0.2)' }}
        >
          {error && (
            <motion.div
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="mb-6 px-4 py-3 rounded-lg text-sm font-body"
              style={{
                background: 'rgba(255, 45, 120, 0.1)',
                border: '1px solid rgba(255, 45, 120, 0.3)',
                color: '#ff2d78',
              }}
            >
              {error}
            </motion.div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="font-mono text-xs text-slate-400 tracking-widest block mb-2">
                EMAIL
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                className="neon-input w-full px-4 py-3 rounded-lg"
              />
            </div>

            <div>
              <label className="font-mono text-xs text-slate-400 tracking-widest block mb-2">
                PASSWORD
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="neon-input w-full px-4 py-3 rounded-lg"
              />
            </div>

            <div className="flex items-center justify-between text-xs font-mono">
              <label className="flex items-center gap-2 text-slate-400 cursor-pointer">
                <input type="checkbox" className="accent-purple-500" />
                REMEMBER ME
              </label>
              <span className="text-neon-cyan cursor-pointer hover:opacity-80">
                FORGOT PASSWORD?
              </span>
            </div>

            <motion.button
              type="submit"
              disabled={loading}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="btn-neon-cyan w-full py-4 rounded-lg text-sm relative overflow-hidden"
              style={{ letterSpacing: '0.2em' }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <motion.span
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                    className="inline-block w-4 h-4 border-2 border-dark-base border-t-transparent rounded-full"
                  />
                  AUTHENTICATING...
                </span>
              ) : (
                '→ SIGN IN'
              )}
            </motion.button>
          </form>

          <div className="mt-8 pt-6 border-t border-dark-border text-center">
            <p className="font-body text-slate-400 text-sm">
              No account?{' '}
              <Link href="/register">
                <span className="text-neon-pink hover:opacity-80 cursor-pointer font-semibold">
                  CREATE ONE
                </span>
              </Link>
            </p>
          </div>
        </div>

        {/* Demo hint */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center font-mono text-xs text-slate-600 mt-6 tracking-wider"
        >
          DEMO: ANY CREDENTIALS WORK
        </motion.p>
      </motion.div>
    </div>
  )
}
