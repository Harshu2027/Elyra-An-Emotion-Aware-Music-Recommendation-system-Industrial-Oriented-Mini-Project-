'use client'
import { motion, useScroll, useTransform } from 'framer-motion'
import Link from 'next/link'
import { useRef, useEffect, useState } from 'react'

const EMOTIONS = ['HAPPY', 'SAD', 'ANGRY', 'SURPRISED', 'NEUTRAL']
const EMOTION_COLORS: Record<string, string> = {
  HAPPY: '#ff2d78',
  SAD: '#00f5ff',
  ANGRY: '#ff6b00',
  SURPRISED: '#bf00ff',
  NEUTRAL: '#39ff14',
}

function FloatingParticles() {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    size: Math.random() * 4 + 1,
    x: Math.random() * 100,
    y: Math.random() * 100,
    duration: Math.random() * 8 + 4,
    delay: Math.random() * 5,
    color: ['#ff2d78', '#00f5ff', '#bf00ff'][Math.floor(Math.random() * 3)],
  }))

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {particles.map((p) => (
        <motion.div
          key={p.id}
          className="absolute rounded-full"
          style={{
            width: p.size, height: p.size,
            left: `${p.x}%`, top: `${p.y}%`,
            background: p.color,
            boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
          }}
          animate={{
            y: [-20, -60, -20],
            x: [-10, 10, -10],
            opacity: [0.3, 0.9, 0.3],
            scale: [1, 1.5, 1],
          }}
          transition={{
            duration: p.duration,
            delay: p.delay,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  )
}

function RotatingRing({ size, color, duration, reverse = false }: {
  size: number; color: string; duration: number; reverse?: boolean
}) {
  return (
    <motion.div
      className="absolute rounded-full border opacity-20"
      style={{
        width: size, height: size,
        borderColor: color,
        borderStyle: 'dashed',
        boxShadow: `0 0 30px ${color}30`,
        marginLeft: -size / 2,
        marginTop: -size / 2,
        left: '50%', top: '50%',
      }}
      animate={{ rotate: reverse ? -360 : 360 }}
      transition={{ duration, repeat: Infinity, ease: 'linear' }}
    />
  )
}

export default function LandingPage() {
  const [currentEmotion, setCurrentEmotion] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentEmotion((prev) => (prev + 1) % EMOTIONS.length)
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  const emotion = EMOTIONS[currentEmotion]
  const emotionColor = EMOTION_COLORS[emotion]

  return (
    <div className="min-h-screen relative overflow-hidden">
      <FloatingParticles />

      {/* Hero Section */}
      <section
        ref={heroRef}
        className="relative flex flex-col items-center justify-center min-h-screen px-6 text-center"
      >
        {/* Rotating rings behind logo */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <RotatingRing size={500} color="#bf00ff" duration={20} />
          <RotatingRing size={650} color="#ff2d78" duration={30} reverse />
          <RotatingRing size={800} color="#00f5ff" duration={45} />
        </div>

        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mb-8 inline-flex items-center gap-2 px-4 py-2 rounded-full"
          style={{
            background: 'rgba(191, 0, 255, 0.1)',
            border: '1px solid rgba(191, 0, 255, 0.4)',
          }}
        >
          <motion.span
            className="w-2 h-2 rounded-full bg-neon-purple"
            animate={{ opacity: [1, 0.3, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          />
          <span className="font-mono text-xs text-purple-300 tracking-widest">
            AI-POWERED EMOTION DETECTION
          </span>
        </motion.div>

        {/* Main Title */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.4, type: 'spring', stiffness: 100 }}
        >
          <h1
            className="font-display font-black text-8xl md:text-[10rem] tracking-widest leading-none mb-2"
            style={{
              background: 'linear-gradient(135deg, #ff2d78 0%, #bf00ff 50%, #00f5ff 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
              filter: 'drop-shadow(0 0 40px rgba(191,0,255,0.4))',
              letterSpacing: '0.2em',
            }}
          >
            EYLARA
          </h1>
        </motion.div>

        {/* Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="font-body text-xl md:text-2xl text-slate-300 tracking-widest mt-4 mb-3"
          style={{ letterSpacing: '0.3em' }}
        >
          FEEL THE MUSIC · FEED THE SOUL
        </motion.p>

        {/* Dynamic emotion display */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="flex items-center gap-3 mb-12"
        >
          <span className="font-mono text-sm text-slate-500 tracking-widest">CURRENT VIBE:</span>
          <motion.span
            key={emotion}
            initial={{ opacity: 0, x: 20, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.4 }}
            className="font-display font-bold text-sm tracking-widest px-4 py-1 rounded-full"
            style={{
              color: emotionColor,
              background: `${emotionColor}18`,
              border: `1px solid ${emotionColor}60`,
              boxShadow: `0 0 20px ${emotionColor}30`,
              letterSpacing: '0.2em',
            }}
          >
            {emotion}
          </motion.span>
        </motion.div>

        {/* CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.4 }}
          className="flex flex-col sm:flex-row gap-4 items-center"
        >
          <Link href="/detect">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="btn-neon-pink px-10 py-4 text-sm rounded-xl"
              style={{ letterSpacing: '0.2em' }}
            >
              ✦ GET STARTED
            </motion.button>
          </Link>
          <Link href="/dashboard">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="btn-outline-neon px-10 py-4 text-sm rounded-xl"
              style={{ letterSpacing: '0.2em' }}
            >
              DASHBOARD
            </motion.button>
          </Link>
        </motion.div>

        {/* Scroll hint */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.5 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="flex flex-col items-center gap-2"
          >
            <span className="font-mono text-xs text-slate-600 tracking-widest">SCROLL</span>
            <div className="w-px h-12 bg-gradient-to-b from-purple-500 to-transparent" />
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-6 max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2
            className="font-display font-black text-4xl md:text-5xl mb-4"
            style={{ letterSpacing: '0.15em' }}
          >
            <span className="neon-text-purple">HOW IT</span>{' '}
            <span className="neon-text-cyan">WORKS</span>
          </h2>
          <p className="font-body text-slate-400 text-lg tracking-wider">
            Three steps to your perfect soundtrack
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              step: '01',
              title: 'SCAN YOUR FACE',
              desc: 'Our AI analyzes your webcam feed to detect micro-expressions and emotional states in real time.',
              icon: '◎',
              color: '#ff2d78',
              delay: 0,
            },
            {
              step: '02',
              title: 'IDENTIFY EMOTION',
              desc: 'Advanced algorithms classify your current mood: happy, sad, angry, surprised, or neutral.',
              icon: '◈',
              color: '#bf00ff',
              delay: 0.15,
            },
            {
              step: '03',
              title: 'GET YOUR MUSIC',
              desc: 'Receive a curated playlist perfectly matched to your emotional state and vibe.',
              icon: '♫',
              color: '#00f5ff',
              delay: 0.3,
            },
          ].map((item) => (
            <motion.div
              key={item.step}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: item.delay }}
              whileHover={{ y: -8 }}
              className="glass-card p-8 text-center group cursor-default"
              style={{ borderColor: `${item.color}30` }}
            >
              <div
                className="text-5xl mb-4 transition-all duration-300 group-hover:scale-110"
                style={{
                  color: item.color,
                  filter: `drop-shadow(0 0 15px ${item.color})`,
                }}
              >
                {item.icon}
              </div>
              <div
                className="font-display font-black text-xs mb-3 tracking-widest"
                style={{ color: `${item.color}80` }}
              >
                STEP {item.step}
              </div>
              <h3
                className="font-display font-bold text-lg mb-3 tracking-wider"
                style={{ color: item.color }}
              >
                {item.title}
              </h3>
              <p className="font-body text-slate-400 text-base leading-relaxed">
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA bottom section */}
      <section className="py-24 px-6 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="glass-card max-w-3xl mx-auto p-16"
          style={{ borderColor: 'rgba(255, 45, 120, 0.3)' }}
        >
          <h2
            className="font-display font-black text-4xl mb-4 neon-text-pink"
            style={{ letterSpacing: '0.1em' }}
          >
            READY TO FEEL?
          </h2>
          <p className="font-body text-slate-400 text-lg mb-8 tracking-wide">
            Let EYLARA tune into your emotions and craft the perfect musical experience.
          </p>
          <Link href="/register">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="btn-neon-pink px-12 py-4 text-sm rounded-xl"
              style={{ letterSpacing: '0.2em' }}
            >
              ✦ START FREE
            </motion.button>
          </Link>
        </motion.div>
      </section>
    </div>
  )
}
