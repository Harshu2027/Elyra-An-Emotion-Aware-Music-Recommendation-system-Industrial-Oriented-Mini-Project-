'use client'
import './globals.css'
import { motion, AnimatePresence } from 'framer-motion'
import { usePathname } from 'next/navigation'
import Link from 'next/link'
import { useState, useEffect } from 'react'

function NavBar() {
  const pathname = usePathname()
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const isHome = pathname === '/'
  if (isHome) return null

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass-card rounded-none border-x-0 border-t-0' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/">
          <span
            className="font-display font-black text-xl tracking-widest neon-text-cyan cursor-pointer"
            style={{ letterSpacing: '0.25em' }}
          >
            EYLARA
          </span>
        </Link>
        <div className="flex items-center gap-6">
          {[
            { href: '/dashboard', label: 'DASHBOARD' },
            { href: '/detect', label: 'DETECT' },
            { href: '/music', label: 'MUSIC' },
          ].map((item) => (
            <Link key={item.href} href={item.href}>
              <span
                className={`font-mono text-xs tracking-widest cursor-pointer transition-all duration-300 hover:text-neon-cyan ${
                  pathname === item.href
                    ? 'text-neon-cyan neon-text-cyan'
                    : 'text-slate-400'
                }`}
              >
                {item.label}
              </span>
            </Link>
          ))}
          <Link href="/login">
            <button className="btn-outline-neon text-xs px-4 py-2 rounded-lg">
              LOGIN
            </button>
          </Link>
        </div>
      </div>
    </motion.nav>
  )
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const pathname = usePathname()

  return (
    <html lang="en">
      <head>
        <title>EYLARA – Emotion-Based Music Recommender</title>
        <meta name="description" content="AI-powered emotion detection meets personalized music" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;600;700&family=Share+Tech+Mono&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="grid-bg min-h-screen">
        {/* Scan line effect */}
        <div className="scan-line" />

        {/* Ambient background orbs */}
        <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
          <div
            className="absolute rounded-full opacity-10 blur-3xl"
            style={{
              width: '600px', height: '600px',
              background: 'radial-gradient(circle, #bf00ff, transparent)',
              top: '-200px', left: '-200px',
            }}
          />
          <div
            className="absolute rounded-full opacity-8 blur-3xl"
            style={{
              width: '500px', height: '500px',
              background: 'radial-gradient(circle, #ff2d78, transparent)',
              bottom: '-150px', right: '-150px',
            }}
          />
          <div
            className="absolute rounded-full opacity-6 blur-3xl"
            style={{
              width: '400px', height: '400px',
              background: 'radial-gradient(circle, #00f5ff, transparent)',
              top: '40%', right: '10%',
            }}
          />
        </div>

        <NavBar />
        <main className="relative z-10">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.35, ease: 'easeInOut' }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </body>
    </html>
  )
}
