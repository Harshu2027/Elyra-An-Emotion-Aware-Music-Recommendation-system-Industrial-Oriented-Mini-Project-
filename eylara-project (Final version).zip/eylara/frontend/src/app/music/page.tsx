'use client'
import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { getSongs, getEmotionConfig, type Emotion, type Song } from '@/lib/songs'

function SongCard({ song, index, color }: { song: Song; index: number; color: string }) {
  const [playing, setPlaying] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.07 + 0.3, duration: 0.5 }}
      whileHover={{ y: -6, scale: 1.02 }}
      className="song-card glass-card p-5 cursor-pointer"
      style={{ borderColor: `${color}25` }}
      onClick={() => setPlaying((p) => !p)}
    >
      {/* Play button + track info */}
      <div className="flex items-center gap-4">
        {/* Play/pause circle */}
        <motion.div
          className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0"
          style={{
            background: playing ? color : `${color}18`,
            border: `1.5px solid ${color}60`,
            boxShadow: playing ? `0 0 20px ${color}60` : undefined,
          }}
          whileTap={{ scale: 0.9 }}
        >
          <span style={{ color: playing ? '#0f0f1a' : color, fontSize: '16px' }}>
            {playing ? '■' : '▶'}
          </span>
        </motion.div>

        <div className="flex-1 min-w-0">
          <h4
            className="font-body font-semibold text-base truncate"
            style={{ color: playing ? color : '#e0e0ff' }}
          >
            {song.title}
          </h4>
          <p className="font-body text-sm text-slate-400 truncate">{song.artist}</p>
        </div>

        <div className="text-right flex-shrink-0">
          <p className="font-mono text-xs text-slate-500">{song.duration}</p>
          <p
            className="font-mono text-xs mt-0.5"
            style={{ color: `${color}99` }}
          >
            {song.bpm} BPM
          </p>
        </div>
      </div>

      {/* Metadata chips */}
      <div className="flex items-center gap-2 mt-3">
        <span
          className="px-2.5 py-0.5 rounded-full font-mono text-xs"
          style={{
            background: `${color}12`,
            border: `1px solid ${color}30`,
            color: `${color}cc`,
          }}
        >
          {song.genre}
        </span>
        <span
          className="px-2.5 py-0.5 rounded-full font-mono text-xs"
          style={{
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
            color: 'rgba(160,160,200,0.6)',
          }}
        >
          {song.mood}
        </span>

        {/* Sound wave when playing */}
        {playing && (
          <div className="flex items-end gap-0.5 ml-auto h-4">
            {[3, 5, 7, 5, 3, 7, 4].map((h, i) => (
              <motion.div
                key={i}
                className="w-1 rounded-full"
                style={{ background: color }}
                animate={{ height: [h, h * 2, h] }}
                transition={{
                  duration: 0.5,
                  delay: i * 0.08,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              />
            ))}
          </div>
        )}
      </div>
    </motion.div>
  )
}

const ALL_EMOTIONS: Emotion[] = ['happy', 'sad', 'angry', 'surprised', 'neutral', 'fearful', 'disgusted']

export default function MusicPage() {
  const [activeEmotion, setActiveEmotion] = useState<Emotion>('happy')

  useEffect(() => {
    const saved = sessionStorage.getItem('eylara_emotion') as Emotion | null
    if (saved) setActiveEmotion(saved)
  }, [])

  const config = getEmotionConfig(activeEmotion)
  const songs = getSongs(activeEmotion)

  return (
    <div className="min-h-screen px-6 py-28 max-w-5xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-10 text-center"
      >
        <p className="font-mono text-xs text-slate-500 tracking-widest mb-2">MUSIC RECOMMENDER</p>
        <h1
          className="font-display font-black text-4xl md:text-5xl"
          style={{ letterSpacing: '0.1em' }}
        >
          <span className="neon-text-cyan">YOUR</span>{' '}
          <span className="neon-text-pink">SOUNDTRACK</span>
        </h1>
        <p className="font-body text-slate-400 mt-3 tracking-wide">
          Songs curated for your current emotional state
        </p>
      </motion.div>

      {/* Emotion Selector */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex flex-wrap justify-center gap-3 mb-10"
      >
        {ALL_EMOTIONS.map((emotion) => {
          const cfg = getEmotionConfig(emotion)
          const active = emotion === activeEmotion
          return (
            <motion.button
              key={emotion}
              onClick={() => setActiveEmotion(emotion)}
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-2 rounded-full font-mono text-xs tracking-widest transition-all duration-300 flex items-center gap-2"
              style={{
                background: active ? cfg.color : `${cfg.color}12`,
                border: `1px solid ${active ? cfg.color : `${cfg.color}40`}`,
                color: active ? '#0f0f1a' : cfg.color,
                fontWeight: active ? '700' : '500',
                boxShadow: active ? `0 0 20px ${cfg.color}50` : undefined,
              }}
            >
              <span>{cfg.emoji}</span>
              {cfg.label}
            </motion.button>
          )
        })}
      </motion.div>

      {/* Active emotion header */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeEmotion}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.4 }}
        >
          {/* Emotion Hero Banner */}
          <div
            className="glass-card p-6 mb-6 relative overflow-hidden"
            style={{ borderColor: `${config.color}40` }}
          >
            <div
              className="absolute inset-0 opacity-5"
              style={{ background: config.gradient }}
            />
            <div className="relative flex items-center gap-5">
              <motion.span
                animate={{ scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 3 }}
                className="text-5xl"
              >
                {config.emoji}
              </motion.span>
              <div>
                <h2
                  className="font-display font-black text-2xl mb-1"
                  style={{ color: config.color, letterSpacing: '0.15em' }}
                >
                  {config.label} PLAYLIST
                </h2>
                <p className="font-body text-slate-400 text-sm">{config.description}</p>
                <p
                  className="font-mono text-xs mt-1 tracking-wider"
                  style={{ color: `${config.color}80` }}
                >
                  {config.vibe}
                </p>
              </div>
              <div className="ml-auto text-right">
                <p className="font-mono text-xs text-slate-500 tracking-wider">{songs.length} TRACKS</p>
                <Link href="/detect">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    className="mt-2 px-4 py-2 rounded-lg font-mono text-xs tracking-widest transition-all"
                    style={{
                      background: `${config.color}18`,
                      border: `1px solid ${config.color}40`,
                      color: config.color,
                    }}
                  >
                    ◎ RE-DETECT
                  </motion.button>
                </Link>
              </div>
            </div>
          </div>

          {/* Songs Grid */}
          <div className="grid md:grid-cols-2 gap-4">
            {songs.map((song, i) => (
              <SongCard key={song.id} song={song} index={i} color={config.color} />
            ))}
          </div>

          {/* Footer hint */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
            className="text-center font-mono text-xs text-slate-600 tracking-widest mt-10"
          >
            CLICK A SONG TO SIMULATE PLAYBACK
          </motion.p>
        </motion.div>
      </AnimatePresence>
    </div>
  )
}
