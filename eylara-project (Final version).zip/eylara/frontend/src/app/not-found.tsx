'use client'
import { motion } from 'framer-motion'
import Link from 'next/link'

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, type: 'spring' }}
      >
        {/* Glitching 404 */}
        <motion.h1
          className="font-display font-black text-[10rem] leading-none"
          style={{
            background: 'linear-gradient(135deg, #ff2d78, #bf00ff, #00f5ff)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
            filter: 'drop-shadow(0 0 40px rgba(191,0,255,0.5))',
            letterSpacing: '0.1em',
          }}
          animate={{
            filter: [
              'drop-shadow(0 0 40px rgba(191,0,255,0.5))',
              'drop-shadow(0 0 60px rgba(255,45,120,0.6))',
              'drop-shadow(0 0 40px rgba(0,245,255,0.5))',
              'drop-shadow(0 0 40px rgba(191,0,255,0.5))',
            ],
          }}
          transition={{ duration: 3, repeat: Infinity }}
        >
          404
        </motion.h1>

        <h2
          className="font-display font-bold text-2xl neon-text-cyan mb-4"
          style={{ letterSpacing: '0.2em' }}
        >
          SIGNAL LOST
        </h2>
        <p className="font-body text-slate-400 text-lg mb-10 max-w-md">
          The frequency you're looking for doesn't exist in this dimension.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="btn-neon-pink px-10 py-4 rounded-xl text-sm"
              style={{ letterSpacing: '0.2em' }}
            >
              ← RETURN HOME
            </motion.button>
          </Link>
          <Link href="/detect">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.97 }}
              className="btn-outline-neon px-10 py-4 rounded-xl text-sm"
              style={{ letterSpacing: '0.15em' }}
            >
              ◎ DETECT MOOD
            </motion.button>
          </Link>
        </div>
      </motion.div>

      {/* Glitch lines */}
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="fixed pointer-events-none h-px"
          style={{
            background: i % 2 === 0 ? '#ff2d78' : '#00f5ff',
            top: `${15 + i * 18}%`,
            opacity: 0.15,
            left: 0, right: 0,
          }}
          animate={{ opacity: [0.05, 0.25, 0.05], scaleX: [0.3, 1, 0.3] }}
          transition={{ duration: 2 + i * 0.4, repeat: Infinity, delay: i * 0.3 }}
        />
      ))}
    </div>
  )
}
