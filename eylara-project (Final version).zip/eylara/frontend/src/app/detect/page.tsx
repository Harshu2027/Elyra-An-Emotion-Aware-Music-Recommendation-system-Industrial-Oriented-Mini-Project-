'use client'
import { motion, AnimatePresence } from 'framer-motion'
import { useRef, useState, useCallback, useEffect } from 'react'
import Webcam from 'react-webcam'
import Link from 'next/link'
import { detectEmotion, healthCheck, type EmotionResult } from '@/lib/api'
import { getEmotionConfig } from '@/lib/songs'

type DetectState = 'idle' | 'scanning' | 'success' | 'error' | 'no-backend'

export default function DetectPage() {
  const webcamRef = useRef<Webcam>(null)
  const [state, setState] = useState<DetectState>('idle')
  const [result, setResult] = useState<EmotionResult | null>(null)
  const [error, setError] = useState('')
  const [backendOk, setBackendOk] = useState<boolean | null>(null)
  const [cameraReady, setCameraReady] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)

  // Check backend health on mount
  useEffect(() => {
    healthCheck().then(setBackendOk)
  }, [])

  const handleDetect = useCallback(async () => {
    if (state === 'scanning') return
    setState('scanning')
    setScanProgress(0)
    setError('')
    setResult(null)

    // Animate progress bar
    const interval = setInterval(() => {
      setScanProgress((p) => Math.min(p + Math.random() * 12, 90))
    }, 150)

    try {
      // Capture frame from webcam
      const imageSrc = webcamRef.current?.getScreenshot() ?? undefined
      const frameBase64 = imageSrc?.split(',')[1]

      const data = await detectEmotion(frameBase64)
      clearInterval(interval)
      setScanProgress(100)

      // Save to session
      sessionStorage.setItem('eylara_emotion', data.emotion)
      sessionStorage.setItem('eylara_result', JSON.stringify(data))

      setTimeout(() => {
        setResult(data)
        setState('success')
      }, 400)
    } catch (err) {
      clearInterval(interval)
      const msg = err instanceof Error ? err.message : 'Unknown error'
      setError(msg)
      setState('error')
      setScanProgress(0)
    }
  }, [state])

  const emotionConfig = result ? getEmotionConfig(result.emotion) : null

  return (
    <div className="min-h-screen px-6 py-28 max-w-5xl mx-auto">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-10 text-center"
      >
        <p className="font-mono text-xs text-slate-500 tracking-widest mb-2">EMOTION SCANNER</p>
        <h1
          className="font-display font-black text-4xl md:text-5xl"
          style={{ letterSpacing: '0.1em' }}
        >
          <span className="neon-text-pink">DETECT</span>{' '}
          <span className="neon-text-purple">YOUR MOOD</span>
        </h1>
        <p className="font-body text-slate-400 mt-3 tracking-wide">
          Allow camera access and press scan to detect your current emotion
        </p>
      </motion.div>

      {/* Backend status */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="flex items-center justify-center gap-2 mb-8"
      >
        <motion.div
          animate={{ opacity: backendOk === null ? [1, 0.3, 1] : 1 }}
          transition={{ duration: 1, repeat: backendOk === null ? Infinity : 0 }}
          className="w-2 h-2 rounded-full"
          style={{
            background: backendOk === null ? '#888' : backendOk ? '#39ff14' : '#ff4444',
            boxShadow: backendOk ? '0 0 8px #39ff14' : undefined,
          }}
        />
        <span className="font-mono text-xs text-slate-500 tracking-widest">
          {backendOk === null ? 'CONNECTING TO API...' :
           backendOk ? 'API CONNECTED' :
           'API OFFLINE — DEMO MODE'}
        </span>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8 items-start">
        {/* Webcam Panel */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4, duration: 0.7 }}
        >
          <div
            className="relative rounded-2xl overflow-hidden"
            style={{
              border: `2px solid ${state === 'scanning' ? '#ff2d78' : state === 'success' ? '#39ff14' : 'rgba(191,0,255,0.3)'}`,
              boxShadow: state === 'scanning'
                ? '0 0 30px rgba(255,45,120,0.4)'
                : state === 'success'
                ? '0 0 30px rgba(57,255,20,0.3)'
                : '0 0 20px rgba(191,0,255,0.15)',
              transition: 'border-color 0.5s, box-shadow 0.5s',
            }}
          >
            {/* Webcam */}
            <Webcam
              ref={webcamRef}
              audio={false}
              screenshotFormat="image/jpeg"
              width="100%"
              onUserMedia={() => setCameraReady(true)}
              onUserMediaError={() => setCameraReady(false)}
              style={{ display: 'block', background: '#0a0a15', minHeight: '280px' }}
              videoConstraints={{ width: 640, height: 480, facingMode: 'user' }}
            />

            {/* Scanning overlay */}
            <AnimatePresence>
              {state === 'scanning' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 pointer-events-none"
                >
                  {/* Corner brackets */}
                  {[
                    { top: 12, left: 12, rotate: 0 },
                    { top: 12, right: 12, rotate: 90 },
                    { bottom: 12, right: 12, rotate: 180 },
                    { bottom: 12, left: 12, rotate: 270 },
                  ].map((pos, i) => (
                    <div
                      key={i}
                      className="absolute w-8 h-8"
                      style={{
                        ...pos,
                        borderTop: '2px solid #ff2d78',
                        borderLeft: '2px solid #ff2d78',
                        transform: `rotate(${pos.rotate}deg)`,
                        filter: 'drop-shadow(0 0 6px #ff2d78)',
                      }}
                    />
                  ))}

                  {/* Scan line */}
                  <motion.div
                    className="absolute left-0 right-0 h-0.5"
                    style={{ background: 'linear-gradient(90deg, transparent, #ff2d78, transparent)' }}
                    animate={{ top: ['0%', '100%', '0%'] }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                  />

                  {/* Label */}
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
                    <span
                      className="font-mono text-xs px-3 py-1 rounded-full"
                      style={{
                        background: 'rgba(255,45,120,0.2)',
                        border: '1px solid rgba(255,45,120,0.5)',
                        color: '#ff2d78',
                        letterSpacing: '0.2em',
                      }}
                    >
                      ANALYZING...
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Success overlay */}
            <AnimatePresence>
              {state === 'success' && emotionConfig && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute bottom-4 left-4 right-4"
                >
                  <div
                    className="rounded-xl px-4 py-2 flex items-center gap-2"
                    style={{
                      background: 'rgba(15,15,26,0.85)',
                      border: `1px solid ${emotionConfig.color}60`,
                      backdropFilter: 'blur(10px)',
                    }}
                  >
                    <span className="text-xl">{emotionConfig.emoji}</span>
                    <span
                      className="font-display font-bold text-sm tracking-widest"
                      style={{ color: emotionConfig.color }}
                    >
                      {emotionConfig.label}
                    </span>
                    <span className="font-mono text-xs text-slate-400 ml-auto">
                      {((result?.confidence ?? 0) * 100).toFixed(0)}%
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Progress bar */}
          {state === 'scanning' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mt-3 progress-bar-neon"
            >
              <motion.div
                className="progress-bar-fill"
                style={{
                  width: `${scanProgress}%`,
                  background: 'linear-gradient(90deg, #ff2d78, #bf00ff)',
                }}
              />
            </motion.div>
          )}

          {/* Detect Button */}
          <motion.button
            onClick={handleDetect}
            disabled={state === 'scanning'}
            whileHover={{ scale: state === 'scanning' ? 1 : 1.03 }}
            whileTap={{ scale: state === 'scanning' ? 1 : 0.97 }}
            className="w-full mt-5 py-4 rounded-xl font-display font-bold text-sm tracking-widest transition-all duration-300"
            style={{
              background: state === 'scanning'
                ? 'rgba(255,45,120,0.2)'
                : 'linear-gradient(135deg, #ff2d78, #bf00ff)',
              color: state === 'scanning' ? '#ff2d78' : 'white',
              border: state === 'scanning' ? '1px solid rgba(255,45,120,0.4)' : 'none',
              cursor: state === 'scanning' ? 'not-allowed' : 'pointer',
              letterSpacing: '0.2em',
              boxShadow: state !== 'scanning' ? '0 0 25px rgba(255,45,120,0.4)' : undefined,
            }}
          >
            {state === 'scanning' ? (
              <span className="flex items-center justify-center gap-2">
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="inline-block w-4 h-4 border-2 border-neon-pink border-t-transparent rounded-full"
                />
                SCANNING EMOTION...
              </span>
            ) : (
              '◎ SCAN MY EMOTION'
            )}
          </motion.button>

          {/* Error */}
          {state === 'error' && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 px-4 py-3 rounded-lg font-body text-sm"
              style={{
                background: 'rgba(255,45,120,0.1)',
                border: '1px solid rgba(255,45,120,0.3)',
                color: '#ff2d78',
              }}
            >
              ⚠ {error}
            </motion.div>
          )}
        </motion.div>

        {/* Results Panel */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.7 }}
          className="space-y-5"
        >
          <AnimatePresence mode="wait">
            {state !== 'success' || !result ? (
              <motion.div
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="glass-card p-8 text-center"
              >
                <div className="text-6xl mb-4 opacity-30">◈</div>
                <p className="font-mono text-sm text-slate-500 tracking-wider">
                  AWAITING SCAN
                </p>
                <p className="font-body text-slate-600 text-sm mt-2">
                  Results will appear here
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ type: 'spring', stiffness: 200, damping: 20 }}
              >
                {/* Main emotion result */}
                <div
                  className="glass-card p-6 mb-4"
                  style={{ borderColor: `${emotionConfig!.color}40` }}
                >
                  <p className="font-mono text-xs text-slate-500 tracking-widest mb-3">
                    DETECTED EMOTION
                  </p>
                  <div className="flex items-center gap-3 mb-4">
                    <span className="text-4xl">{emotionConfig!.emoji}</span>
                    <div>
                      <h3
                        className="font-display font-black text-3xl"
                        style={{ color: emotionConfig!.color, letterSpacing: '0.15em' }}
                      >
                        {emotionConfig!.label}
                      </h3>
                      <p className="font-body text-slate-400 text-sm">
                        {emotionConfig!.description}
                      </p>
                    </div>
                  </div>

                  {/* Confidence */}
                  <div className="mb-2">
                    <div className="flex justify-between items-center mb-1">
                      <span className="font-mono text-xs text-slate-500 tracking-wider">CONFIDENCE</span>
                      <span
                        className="font-display font-bold text-sm"
                        style={{ color: emotionConfig!.color }}
                      >
                        {((result.confidence) * 100).toFixed(1)}%
                      </span>
                    </div>
                    <div className="progress-bar-neon">
                      <motion.div
                        className="progress-bar-fill"
                        initial={{ width: 0 }}
                        animate={{ width: `${result.confidence * 100}%` }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        style={{ background: emotionConfig!.gradient }}
                      />
                    </div>
                  </div>
                </div>

                {/* All scores */}
                <div className="glass-card p-5">
                  <p className="font-mono text-xs text-slate-500 tracking-widest mb-4">
                    ALL EMOTION SCORES
                  </p>
                  <div className="space-y-3">
                    {Object.entries(result.all_scores)
                      .sort(([, a], [, b]) => b - a)
                      .map(([emotion, score]) => {
                        const cfg = getEmotionConfig(emotion)
                        return (
                          <div key={emotion} className="flex items-center gap-2">
                            <span className="text-sm w-5">{cfg.emoji}</span>
                            <span className="font-mono text-xs text-slate-400 w-16 tracking-wider uppercase">
                              {emotion}
                            </span>
                            <div className="flex-1 progress-bar-neon">
                              <motion.div
                                className="progress-bar-fill"
                                initial={{ width: 0 }}
                                animate={{ width: `${score * 100}%` }}
                                transition={{ duration: 0.8, delay: 0.2, ease: 'easeOut' }}
                                style={{ background: cfg.color }}
                              />
                            </div>
                            <span className="font-mono text-xs text-slate-500 w-9 text-right">
                              {(score * 100).toFixed(0)}%
                            </span>
                          </div>
                        )
                      })}
                  </div>
                </div>

                {/* CTA */}
                <div className="flex gap-3 mt-4">
                  <Link href="/music" className="flex-1">
                    <motion.button
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.97 }}
                      className="btn-neon-pink w-full py-3 rounded-xl text-xs"
                      style={{ letterSpacing: '0.2em' }}
                    >
                      ♫ GET SONGS
                    </motion.button>
                  </Link>
                  <motion.button
                    onClick={() => { setState('idle'); setResult(null) }}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    className="btn-outline-neon flex-1 py-3 rounded-xl text-xs"
                    style={{ letterSpacing: '0.15em' }}
                  >
                    ↺ RESCAN
                  </motion.button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  )
}
